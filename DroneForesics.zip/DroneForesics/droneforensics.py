#!/usr/bin/env python3
"""
DroneForensics - A forensic analysis tool for drone flight data
Main application entry point
"""

import sys
import os
import argparse
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt
from src.gui.main_window import MainWindow

def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='DroneForensics - Drone Flight Data Analysis Tool')
    parser.add_argument('--cli', action='store_true', help='Run in command-line mode')
    parser.add_argument('--input', help='Input file path')
    parser.add_argument('--output', help='Output report file path')
    parser.add_argument('--format', choices=['pdf', 'html', 'json', 'kml'], default='pdf',
                      help='Output report format')
    return parser.parse_args()

def run_cli_mode(args):
    """Run the application in command-line mode"""
    from src.core.parser import DroneDataParser
    from src.core.analyzer import DroneDataAnalyzer
    from src.core.reporter import ReportGenerator
    
    print("DroneForensics - CLI Mode")
    print(f"Processing file: {args.input}")
    
    if not os.path.exists(args.input):
        print(f"Error: Input file '{args.input}' not found.")
        return 1
    
    try:
        # Parse the input file
        parser = DroneDataParser()
        drone_data = parser.parse_file(args.input)
        
        # Analyze the data
        analyzer = DroneDataAnalyzer(drone_data)
        analysis_results = analyzer.analyze()
        
        # Generate the report
        reporter = ReportGenerator()
        output_path = args.output or f"drone_report.{args.format}"
        reporter.generate_report(analysis_results, output_path, args.format)
        
        print(f"Report generated: {output_path}")
        return 0
    
    except Exception as e:
        print(f"Error processing file: {str(e)}")
        return 1

def run_gui_mode(args):
    """Run the application in GUI mode"""
    # Enable high DPI scaling
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    
    app = QApplication(sys.argv)
    app.setApplicationName("DroneForensics")
    app.setOrganizationName("DroneForensics")
    
    # Create and show the main window
    main_window = MainWindow()
    
    # If input file is specified, open it
    if args.input and os.path.exists(args.input):
        main_window.open_file(args.input)
    
    main_window.show()
    
    # Start the application event loop
    return app.exec_()

def main():
    """Main application entry point"""
    args = parse_arguments()
    
    if args.cli:
        return run_cli_mode(args)
    else:
        return run_gui_mode(args)

if __name__ == "__main__":
    sys.exit(main())
