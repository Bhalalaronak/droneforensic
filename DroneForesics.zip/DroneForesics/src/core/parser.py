#!/usr/bin/env python3
"""
DroneForensics - Data Parser
Parses drone data from various file formats
"""

import os
import csv
import json
import struct
import datetime
import pandas as pd
import numpy as np
from ..models.telemetry import DroneData

class DroneDataParser:
    """Parser for drone data files"""
    
    def __init__(self):
        self.supported_formats = {
            'csv': self.parse_csv,
            'dat': self.parse_dat,
            'bin': self.parse_bin,
            'log': self.parse_log,
            'txt': self.parse_txt
        }
    
    def detect_format(self, file_path):
        """Detect the format of a drone data file"""
        # First check by extension
        _, ext = os.path.splitext(file_path)
        ext = ext.lower().lstrip('.')
        
        if ext in self.supported_formats:
            return ext
        
        # If extension is not recognized, try to detect by content
        with open(file_path, 'rb') as f:
            header = f.read(16)  # Read first 16 bytes
            
            # Check for CSV
            if b',' in header and (b'\n' in header or b'\r' in header):
                return 'csv'
            
            # Check for DJI DAT file
            if header.startswith(b'\x55\xaa\x55\xaa'):
                return 'dat'
            
            # Check for binary file
            if any(c < 32 and c not in (9, 10, 13) for c in header):
                return 'bin'
            
            # Default to text
            return 'txt'
    
    def parse_file(self, file_path, progress_callback=None):
        """Parse a drone data file"""
        file_format = self.detect_format(file_path)
        
        if file_format in self.supported_formats:
            parser_func = self.supported_formats[file_format]
            return parser_func(file_path, progress_callback)
        else:
            raise ValueError(f"Unsupported file format: {file_format}")
    
    def parse_csv(self, file_path, progress_callback=None):
        """Parse a CSV drone data file"""
        try:
            # First, determine the CSV format by examining headers
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                # Read a few lines to determine format
                header = f.readline().strip()
                sample_line = f.readline().strip()
            
            # Check if this is a DJI CSV format
            if 'OSD.latitude' in header or 'GPS:Lat' in header or 'latitude' in header.lower():
                return self.parse_dji_csv(file_path, progress_callback)
            
            # Check if this is a Parrot CSV format
            elif 'latitude' in header.lower() and 'longitude' in header.lower() and 'altitude' in header.lower():
                return self.parse_parrot_csv(file_path, progress_callback)
            
            # Check if this is a generic CSV with GPS data
            elif ('lat' in header.lower() and 'lon' in header.lower()) or ('latitude' in header.lower() and 'longitude' in header.lower()):
                return self.parse_generic_csv(file_path, progress_callback)
            
            # If format is not recognized, try generic CSV parser
            else:
                return self.parse_generic_csv(file_path, progress_callback)
        
        except Exception as e:
            raise ValueError(f"Error parsing CSV file: {str(e)}")
    
    def parse_dji_csv(self, file_path, progress_callback=None):
        """Parse a DJI format CSV file"""
        try:
            # Read the CSV file
            df = pd.read_csv(file_path)
            
            # Notify progress
            if progress_callback:
                progress_callback(30, "CSV file loaded, processing DJI format...")
            
            # Initialize drone data
            drone_data = DroneData()
            drone_data.set_drone_type("DJI")
            
            # Map column names to standardized names
            column_mapping = self.detect_dji_columns(df.columns)
            
            # Extract flight path data
            flight_path = []
            total_rows = len(df)
            
            for i, row in df.iterrows():
                # Update progress every 1000 rows
                if progress_callback and i % 1000 == 0:
                    progress = 30 + (i / total_rows * 60)
                    progress_callback(progress, f"Processing row {i}/{total_rows}...")
                
                point = {}
                
                # Extract data using the column mapping
                if 'timestamp' in column_mapping and column_mapping['timestamp'] in row:
                    point['timestamp'] = row[column_mapping['timestamp']]
                
                if 'latitude' in column_mapping and column_mapping['latitude'] in row:
                    point['latitude'] = row[column_mapping['latitude']]
                
                if 'longitude' in column_mapping and column_mapping['longitude'] in row:
                    point['longitude'] = row[column_mapping['longitude']]
                
                if 'altitude' in column_mapping and column_mapping['altitude'] in row:
                    point['altitude'] = row[column_mapping['altitude']]
                
                if 'speed' in column_mapping and column_mapping['speed'] in row:
                    point['speed'] = row[column_mapping['speed']]
                
                if 'heading' in column_mapping and column_mapping['heading'] in row:
                    point['heading'] = row[column_mapping['heading']]
                
                # Add additional telemetry if available
                for key, col in column_mapping.items():
                    if key not in ['timestamp', 'latitude', 'longitude', 'altitude', 'speed', 'heading'] and col in row:
                        point[key] = row[col]
                
                # Only add points with valid coordinates
                if 'latitude' in point and 'longitude' in point:
                    if pd.notna(point['latitude']) and pd.notna(point['longitude']):
                        flight_path.append(point)
            
            # Set flight path data
            drone_data.set_flight_path(flight_path)
            
            # Extract home point if available
            if 'home_latitude' in column_mapping and 'home_longitude' in column_mapping:
                home_lat_col = column_mapping['home_latitude']
                home_lon_col = column_mapping['home_longitude']
                
                if home_lat_col in df.columns and home_lon_col in df.columns:
                    # Get first non-NaN value
                    home_lat = df[home_lat_col].dropna().iloc[0] if not df[home_lat_col].dropna().empty else None
                    home_lon = df[home_lon_col].dropna().iloc[0] if not df[home_lon_col].dropna().empty else None
                    
                    if home_lat is not None and home_lon is not None:
                        drone_data.set_home_point({
                            'latitude': home_lat,
                            'longitude': home_lon
                        })
            
            # Extract payload data if available
            if 'gimbal_pitch' in column_mapping or 'camera_in_use' in column_mapping:
                payload_data = []
                
                for i, row in df.iterrows():
                    payload_point = {}
                    
                    # Add timestamp if available
                    if 'timestamp' in column_mapping and column_mapping['timestamp'] in row:
                        payload_point['timestamp'] = row[column_mapping['timestamp']]
                    
                    # Add gimbal data if available
                    for key in ['gimbal_pitch', 'gimbal_roll', 'gimbal_yaw']:
                        if key in column_mapping and column_mapping[key] in row:
                            payload_point[key] = row[column_mapping[key]]
                    
                    # Add camera data if available
                    for key in ['camera_in_use', 'recording', 'photo_taken']:
                        if key in column_mapping and column_mapping[key] in row:
                            payload_point[key] = row[column_mapping[key]]
                    
                    if payload_point:
                        payload_data.append(payload_point)
                
                if payload_data:
                    drone_data.set_payload_data(payload_data)
            
            # Notify completion
            if progress_callback:
                progress_callback(90, "Processing complete, finalizing data...")
            
            return drone_data
        
        except Exception as e:
            raise ValueError(f"Error parsing DJI CSV file: {str(e)}")
    
    def detect_dji_columns(self, columns):
        """Detect and map DJI CSV column names to standardized names"""
        column_mapping = {}
        
        # Convert columns to list of strings if it's not already
        columns = [str(col) for col in columns]
        
        # Map timestamp columns
        timestamp_columns = ['datetime', 'DATE', 'createTime', 'timestamp', 'OSD.timestamp']
        for col in columns:
            if any(tc.lower() in col.lower() for tc in timestamp_columns):
                column_mapping['timestamp'] = col
                break
        
        # Map latitude columns
        lat_columns = ['latitude', 'OSD.latitude', 'GPS:Lat', 'lat']
        for col in columns:
            if any(lc.lower() in col.lower() for lc in lat_columns):
                column_mapping['latitude'] = col
                break
        
        # Map longitude columns
        lon_columns = ['longitude', 'OSD.longitude', 'GPS:Lng', 'lon', 'long']
        for col in columns:
            if any(lc.lower() in col.lower() for lc in lon_columns):
                column_mapping['longitude'] = col
                break
        
        # Map altitude columns
        alt_columns = ['altitude', 'OSD.altitude', 'GPS:Alt', 'alt', 'height']
        for col in columns:
            if any(ac.lower() in col.lower() for ac in alt_columns):
                column_mapping['altitude'] = col
                break
        
        # Map speed columns
        speed_columns = ['speed', 'OSD.speed', 'GPS:Spd', 'hSpeed', 'horizontalSpeed']
        for col in columns:
            if any(sc.lower() in col.lower() for sc in speed_columns):
                column_mapping['speed'] = col
                break
        
        # Map heading columns
        heading_columns = ['heading', 'OSD.heading', 'GPS:Head', 'yaw', 'direction']
        for col in columns:
            if any(hc.lower() in col.lower() for hc in heading_columns):
                column_mapping['heading'] = col
                break
        
        # Map home point columns
        home_lat_columns = ['homeLatitude', 'home_latitude', 'OSD.homeLatitude']
        for col in columns:
            if any(hlc.lower() in col.lower() for hlc in home_lat_columns):
                column_mapping['home_latitude'] = col
                break
        
        home_lon_columns = ['homeLongitude', 'home_longitude', 'OSD.homeLongitude']
        for col in columns:
            if any(hlc.lower() in col.lower() for hlc in home_lon_columns):
                column_mapping['home_longitude'] = col
                break
        
        # Map gimbal columns
        gimbal_pitch_columns = ['gimbalPitch', 'gimbal_pitch', 'OSD.gimbalPitch']
        for col in columns:
            if any(gpc.lower() in col.lower() for gpc in gimbal_pitch_columns):
                column_mapping['gimbal_pitch'] = col
                break
        
        gimbal_roll_columns = ['gimbalRoll', 'gimbal_roll', 'OSD.gimbalRoll']
        for col in columns:
            if any(grc.lower() in col.lower() for grc in gimbal_roll_columns):
                column_mapping['gimbal_roll'] = col
                break
        
        gimbal_yaw_columns = ['gimbalYaw', 'gimbal_yaw', 'OSD.gimbalYaw']
        for col in columns:
            if any(gyc.lower() in col.lower() for gyc in gimbal_yaw_columns):
                column_mapping['gimbal_yaw'] = col
                break
        
        # Map camera columns
        camera_columns = ['cameraInUse', 'camera_in_use', 'OSD.cameraInUse']
        for col in columns:
            if any(cc.lower() in col.lower() for cc in camera_columns):
                column_mapping['camera_in_use'] = col
                break
        
        recording_columns = ['isRecording', 'recording', 'OSD.isRecording']
        for col in columns:
            if any(rc.lower() in col.lower() for rc in recording_columns):
                column_mapping['recording'] = col
                break
        
        photo_columns = ['isPhotoTaken', 'photo_taken', 'OSD.isPhotoTaken']
        for col in columns:
            if any(pc.lower() in col.lower() for pc in photo_columns):
                column_mapping['photo_taken'] = col
                break
        
        # Map battery columns
        battery_columns = ['batterylevel', 'battery', 'OSD.batteryLevel']
        for col in columns:
            if any(bc.lower() in col.lower() for bc in battery_columns):
                column_mapping['battery'] = col
                break
        
        return column_mapping
    
    def parse_parrot_csv(self, file_path, progress_callback=None):
        """Parse a Parrot format CSV file"""
        try:
            # Read the CSV file
            df = pd.read_csv(file_path)
            
            # Notify progress
            if progress_callback:
                progress_callback(30, "CSV file loaded, processing Parrot format...")
            
            # Initialize drone data
            drone_data = DroneData()
            drone_data.set_drone_type("Parrot")
            
            # Map column names to standardized names
            column_mapping = self.detect_parrot_columns(df.columns)
            
            # Extract flight path data
            flight_path = []
            total_rows = len(df)
            
            for i, row in df.iterrows():
                # Update progress every 1000 rows
                if progress_callback and i % 1000 == 0:
                    progress = 30 + (i / total_rows * 60)
                    progress_callback(progress, f"Processing row {i}/{total_rows}...")
                
                point = {}
                
                # Extract data using the column mapping
                if 'timestamp' in column_mapping and column_mapping['timestamp'] in row:
                    point['timestamp'] = row[column_mapping['timestamp']]
                
                if 'latitude' in column_mapping and column_mapping['latitude'] in row:
                    point['latitude'] = row[column_mapping['latitude']]
                
                if 'longitude' in column_mapping and column_mapping['longitude'] in row:
                    point['longitude'] = row[column_mapping['longitude']]
                
                if 'altitude' in column_mapping and column_mapping['altitude'] in row:
                    point['altitude'] = row[column_mapping['altitude']]
                
                if 'speed' in column_mapping and column_mapping['speed'] in row:
                    point['speed'] = row[column_mapping['speed']]
                
                if 'heading' in column_mapping and column_mapping['heading'] in row:
                    point['heading'] = row[column_mapping['heading']]
                
                # Add additional telemetry if available
                for key, col in column_mapping.items():
                    if key not in ['timestamp', 'latitude', 'longitude', 'altitude', 'speed', 'heading'] and col in row:
                        point[key] = row[col]
                
                # Only add points with valid coordinates
                if 'latitude' in point and 'longitude' in point:
                    if pd.notna(point['latitude']) and pd.notna(point['longitude']):
                        flight_path.append(point)
            
            # Set flight path data
            drone_data.set_flight_path(flight_path)
            
            # Notify completion
            if progress_callback:
                progress_callback(90, "Processing complete, finalizing data...")
            
            return drone_data
        
        except Exception as e:
            raise ValueError(f"Error parsing Parrot CSV file: {str(e)}")
    
    def detect_parrot_columns(self, columns):
        """Detect and map Parrot CSV column names to standardized names"""
        column_mapping = {}
        
        # Convert columns to list of strings if it's not already
        columns = [str(col) for col in columns]
        
        # Map timestamp columns
        timestamp_columns = ['time', 'timestamp', 'utc', 'date']
        for col in columns:
            if any(tc.lower() in col.lower() for tc in timestamp_columns):
                column_mapping['timestamp'] = col
                break
        
        # Map latitude columns
        lat_columns = ['latitude', 'lat', 'gps_lat']
        for col in columns:
            if any(lc.lower() in col.lower() for lc in lat_columns):
                column_mapping['latitude'] = col
                break
        
        # Map longitude columns
        lon_columns = ['longitude', 'lon', 'long', 'gps_lon']
        for col in columns:
            if any(lc.lower() in col.lower() for lc in lon_columns):
                column_mapping['longitude'] = col
                break
        
        # Map altitude columns
        alt_columns = ['altitude', 'alt', 'gps_altitude', 'height']
        for col in columns:
            if any(ac.lower() in col.lower() for ac in alt_columns):
                column_mapping['altitude'] = col
                break
        
        # Map speed columns
        speed_columns = ['speed', 'gps_speed', 'ground_speed']
        for col in columns:
            if any(sc.lower() in col.lower() for sc in speed_columns):
                column_mapping['speed'] = col
                break
        
        # Map heading columns
        heading_columns = ['heading', 'yaw', 'direction', 'course']
        for col in columns:
            if any(hc.lower() in col.lower() for hc in heading_columns):
                column_mapping['heading'] = col
                break
        
        # Map battery columns
        battery_columns = ['battery', 'battery_level', 'battery_percentage']
        for col in columns:
            if any(bc.lower() in col.lower() for bc in battery_columns):
                column_mapping['battery'] = col
                break
        
        return column_mapping
    
    def parse_generic_csv(self, file_path, progress_callback=None):
        """Parse a generic CSV file with GPS data"""
        try:
            # Read the CSV file
            df = pd.read_csv(file_path)
            
            # Notify progress
            if progress_callback:
                progress_callback(30, "CSV file loaded, processing generic format...")
            
            # Initialize drone data
            drone_data = DroneData()
            drone_data.set_drone_type("Unknown")
            
            # Try to detect column names
            column_mapping = {}
            
            # Convert columns to list of strings if it's not already
            columns = [str(col) for col in df.columns]
            
            # Map timestamp columns
            timestamp_columns = ['time', 'timestamp', 'datetime', 'date', 'utc']
            for col in columns:
                if any(tc.lower() in col.lower() for tc in timestamp_columns):
                    column_mapping['timestamp'] = col
                    break
            
            # Map latitude columns
            lat_columns = ['latitude', 'lat', 'gps_lat']
            for col in columns:
                if any(lc.lower() in col.lower() for lc in lat_columns):
                    column_mapping['latitude'] = col
                    break
            
            # Map longitude columns
            lon_columns = ['longitude', 'lon', 'long', 'lng', 'gps_lon']
            for col in columns:
                if any(lc.lower() in col.lower() for lc in lon_columns):
                    column_mapping['longitude'] = col
                    break
            
            # Map altitude columns
            alt_columns = ['altitude', 'alt', 'height', 'elevation']
            for col in columns:
                if any(ac.lower() in col.lower() for ac in alt_columns):
                    column_mapping['altitude'] = col
                    break
            
            # Map speed columns
            speed_columns = ['speed', 'velocity', 'ground_speed']
            for col in columns:
                if any(sc.lower() in col.lower() for sc in speed_columns):
                    column_mapping['speed'] = col
                    break
            
            # Map heading columns
            heading_columns = ['heading', 'yaw', 'direction', 'course', 'track']
            for col in columns:
                if any(hc.lower() in col.lower() for hc in heading_columns):
                    column_mapping['heading'] = col
                    break
            
            # Extract flight path data
            flight_path = []
            total_rows = len(df)
            
            for i, row in df.iterrows():
                # Update progress every 1000 rows
                if progress_callback and i % 1000 == 0:
                    progress = 30 + (i / total_rows * 60)
                    progress_callback(progress, f"Processing row {i}/{total_rows}...")
                
                point = {}
                
                # Extract data using the column mapping
                for key, col in column_mapping.items():
                    if col in row:
                        point[key] = row[col]
                
                # Only add points with valid coordinates
                if 'latitude' in point and 'longitude' in point:
                    if pd.notna(point['latitude']) and pd.notna(point['longitude']):
                        flight_path.append(point)
            
            # Set flight path data
            drone_data.set_flight_path(flight_path)
            
            # Notify completion
            if progress_callback:
                progress_callback(90, "Processing complete, finalizing data...")
            
            return drone_data
        
        except Exception as e:
            raise ValueError(f"Error parsing generic CSV file: {str(e)}")
    
    def parse_dat(self, file_path, progress_callback=None):
        """Parse a DAT drone data file (DJI format)"""
        try:
            # This is a placeholder for DAT file parsing
            # In a real implementation, this would parse the binary DAT format
            
            if progress_callback:
                progress_callback(50, "DAT parsing not fully implemented yet")
            
            # For now, return empty drone data
            drone_data = DroneData()
            drone_data.set_drone_type("DJI")
            
            # In a real implementation, we would:
            # 1. Parse the DAT file header
            # 2. Extract telemetry records
            # 3. Convert to flight path data
            # 4. Extract payload information
            
            if progress_callback:
                progress_callback(90, "Returning placeholder data for DAT file")
            
            return drone_data
        
        except Exception as e:
            raise ValueError(f"Error parsing DAT file: {str(e)}")
    
    def parse_bin(self, file_path, progress_callback=None):
        """Parse a BIN drone data file"""
        try:
            # This is a placeholder for BIN file parsing
            # In a real implementation, this would parse various binary formats
            
            if progress_callback:
                progress_callback(50, "BIN parsing not fully implemented yet")
            
            # For now, return empty drone data
            drone_data = DroneData()
            drone_data.set_drone_type("Unknown")
            
            if progress_callback:
                progress_callback(90, "Returning placeholder data for BIN file")
            
            return drone_data
        
        except Exception as e:
            raise ValueError(f"Error parsing BIN file: {str(e)}")
    
    def parse_log(self, file_path, progress_callback=None):
        """Parse a LOG drone data file"""
        try:
            # This is a placeholder for LOG file parsing
            # In a real implementation, this would parse various log formats
            
            if progress_callback:
                progress_callback(50, "LOG parsing not fully implemented yet")
            
            # For now, return empty drone data
            drone_data = DroneData()
            drone_data.set_drone_type("Unknown")
            
            if progress_callback:
                progress_callback(90, "Returning placeholder data for LOG file")
            
            return drone_data
        
        except Exception as e:
            raise ValueError(f"Error parsing LOG file: {str(e)}")
    
    def parse_txt(self, file_path, progress_callback=None):
        """Parse a TXT drone data file"""
        try:
            # First, try to determine if this is a CSV-like format
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                first_lines = [f.readline() for _ in range(5)]
            
            # Check if this looks like a CSV (has commas)
            if any(',' in line for line in first_lines):
                # Try parsing as CSV
                return self.parse_csv(file_path, progress_callback)
            
            # If not CSV-like, this is a placeholder for other text formats
            if progress_callback:
                progress_callback(50, "TXT parsing not fully implemented yet")
            
            # For now, return empty drone data
            drone_data = DroneData()
            drone_data.set_drone_type("Unknown")
            
            if progress_callback:
                progress_callback(90, "Returning placeholder data for TXT file")
            
            return drone_data
        
        except Exception as e:
            raise ValueError(f"Error parsing TXT file: {str(e)}")
