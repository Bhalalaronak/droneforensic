#!/usr/bin/env python3
"""
DroneForensics - Main Window
The primary GUI container for the application
"""

import os
import sys
from PyQt5.QtWidgets import (QMainWindow, QTabWidget, QAction, QFileDialog, 
                           QMessageBox, QToolBar, QStatusBar, QVBoxLayout, 
                           QWidget, QSplitter, QTreeView, QLabel, QComboBox,
                           QPushButton, QHBoxLayout, QProgressBar)
from PyQt5.QtCore import Qt, QSize, pyqtSignal, QThread, QSettings
from PyQt5.QtGui import QIcon, QPixmap

from .map_view import MapView
from .telemetry_view import TelemetryView
from .timeline_view import TimelineView
from .report_view import ReportView

from ..core.parser import DroneDataParser
from ..core.analyzer import DroneDataAnalyzer

class DataLoadThread(QThread):
    """Thread for loading and parsing drone data files"""
    progress_updated = pyqtSignal(int, str)
    data_loaded = pyqtSignal(object)
    error_occurred = pyqtSignal(str)
    
    def __init__(self, file_path):
        super().__init__()
        self.file_path = file_path
    
    def run(self):
        try:
            self.progress_updated.emit(10, "Initializing parser...")
            parser = DroneDataParser()
            
            self.progress_updated.emit(20, "Detecting file format...")
            file_format = parser.detect_format(self.file_path)
            
            self.progress_updated.emit(30, f"Parsing {file_format} file...")
            drone_data = parser.parse_file(self.file_path, 
                                         progress_callback=self.update_parse_progress)
            
            self.progress_updated.emit(90, "Finalizing data...")
            self.data_loaded.emit(drone_data)
            self.progress_updated.emit(100, "Complete")
        
        except Exception as e:
            self.error_occurred.emit(f"Error loading file: {str(e)}")
    
    def update_parse_progress(self, progress, message):
        """Update progress during parsing"""
        # Scale progress to be between 30-90%
        scaled_progress = 30 + (progress * 0.6)
        self.progress_updated.emit(int(scaled_progress), message)

class MainWindow(QMainWindow):
    """Main application window"""
    
    def __init__(self):
        super().__init__()
        
        self.drone_data = None
        self.analyzer = None
        self.current_file = None
        
        self.init_ui()
        self.load_settings()
    
    def init_ui(self):
        """Initialize the user interface"""
        # Set window properties
        self.setWindowTitle("DroneForensics - Drone Flight Data Analysis Tool")
        self.setMinimumSize(1200, 800)
        
        # Create menu bar
        self.create_menu_bar()
        
        # Create toolbar
        self.create_toolbar()
        
        # Create status bar
        self.statusBar = QStatusBar()
        self.setStatusBar(self.statusBar)
        self.statusBar.showMessage("Ready")
        
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Create file info area
        file_info_layout = QHBoxLayout()
        
        self.file_label = QLabel("No file loaded")
        file_info_layout.addWidget(self.file_label)
        
        file_info_layout.addStretch()
        
        self.drone_model_label = QLabel("Drone Model:")
        file_info_layout.addWidget(self.drone_model_label)
        
        self.drone_model_combo = QComboBox()
        self.drone_model_combo.setMinimumWidth(150)
        self.drone_model_combo.setEnabled(False)
        file_info_layout.addWidget(self.drone_model_combo)
        
        main_layout.addLayout(file_info_layout)
        
        # Create tab widget for main content
        self.tabs = QTabWidget()
        
        # Create and add tabs
        self.map_view = MapView()
        self.telemetry_view = TelemetryView()
        self.timeline_view = TimelineView()
        self.report_view = ReportView()
        
        self.tabs.addTab(self.map_view, "Flight Path")
        self.tabs.addTab(self.telemetry_view, "Telemetry")
        self.tabs.addTab(self.timeline_view, "Timeline")
        self.tabs.addTab(self.report_view, "Report")
        
        main_layout.addWidget(self.tabs)
        
        # Create progress bar (hidden by default)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)
        main_layout.addWidget(self.progress_bar)
    
    def create_menu_bar(self):
        """Create the application menu bar"""
        menu_bar = self.menuBar()
        
        # File menu
        file_menu = menu_bar.addMenu("&File")
        
        open_action = QAction("&Open...", self)
        open_action.setShortcut("Ctrl+O")
        open_action.triggered.connect(self.show_file_dialog)
        file_menu.addAction(open_action)
        
        recent_menu = file_menu.addMenu("Recent Files")
        # Will be populated in load_settings
        
        file_menu.addSeparator()
        
        export_menu = file_menu.addMenu("Export")
        
        export_kml_action = QAction("Export to KML...", self)
        export_kml_action.triggered.connect(lambda: self.export_data("kml"))
        export_menu.addAction(export_kml_action)
        
        export_csv_action = QAction("Export to CSV...", self)
        export_csv_action.triggered.connect(lambda: self.export_data("csv"))
        export_menu.addAction(export_csv_action)
        
        export_json_action = QAction("Export to JSON...", self)
        export_json_action.triggered.connect(lambda: self.export_data("json"))
        export_menu.addAction(export_json_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("E&xit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Analysis menu
        analysis_menu = menu_bar.addMenu("&Analysis")
        
        analyze_action = QAction("Analyze Data", self)
        analyze_action.triggered.connect(self.analyze_data)
        analysis_menu.addAction(analyze_action)
        
        analysis_menu.addSeparator()
        
        detect_anomalies_action = QAction("Detect Anomalies", self)
        detect_anomalies_action.triggered.connect(self.detect_anomalies)
        analysis_menu.addAction(detect_anomalies_action)
        
        # Report menu
        report_menu = menu_bar.addMenu("&Report")
        
        generate_report_action = QAction("Generate Report...", self)
        generate_report_action.triggered.connect(self.generate_report)
        report_menu.addAction(generate_report_action)
        
        # Help menu
        help_menu = menu_bar.addMenu("&Help")
        
        about_action = QAction("&About", self)
        about_action.triggered.connect(self.show_about_dialog)
        help_menu.addAction(about_action)
    
    def create_toolbar(self):
        """Create the main toolbar"""
        toolbar = QToolBar("Main Toolbar")
        toolbar.setIconSize(QSize(24, 24))
        self.addToolBar(toolbar)
        
        # Add actions
        open_action = QAction("Open", self)
        open_action.triggered.connect(self.show_file_dialog)
        toolbar.addAction(open_action)
        
        toolbar.addSeparator()
        
        analyze_action = QAction("Analyze", self)
        analyze_action.triggered.connect(self.analyze_data)
        toolbar.addAction(analyze_action)
        
        toolbar.addSeparator()
        
        report_action = QAction("Report", self)
        report_action.triggered.connect(self.generate_report)
        toolbar.addAction(report_action)
    
    def load_settings(self):
        """Load application settings"""
        settings = QSettings()
        
        # Load window geometry
        geometry = settings.value("geometry")
        if geometry:
            self.restoreGeometry(geometry)
        
        # Load recent files
        self.recent_files = settings.value("recentFiles", [])
        self.update_recent_files_menu()
    
    def save_settings(self):
        """Save application settings"""
        settings = QSettings()
        settings.setValue("geometry", self.saveGeometry())
        settings.setValue("recentFiles", self.recent_files)
    
    def update_recent_files_menu(self):
        """Update the recent files menu"""
        recent_menu = self.menuBar().findChild(QMenu, "Recent Files")
        if recent_menu:
            recent_menu.clear()
            
            for file_path in self.recent_files:
                if os.path.exists(file_path):
                    action = QAction(os.path.basename(file_path), self)
                    action.setData(file_path)
                    action.triggered.connect(lambda checked, path=file_path: self.open_file(path))
                    recent_menu.addAction(action)
    
    def add_to_recent_files(self, file_path):
        """Add a file to the recent files list"""
        if file_path in self.recent_files:
            self.recent_files.remove(file_path)
        
        self.recent_files.insert(0, file_path)
        
        # Limit to 10 recent files
        self.recent_files = self.recent_files[:10]
        
        self.update_recent_files_menu()
    
    def show_file_dialog(self):
        """Show file open dialog"""
        file_dialog = QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(
            self,
            "Open Drone Data File",
            "",
            "All Supported Files (*.csv *.dat *.bin *.log *.txt);;CSV Files (*.csv);;DAT Files (*.dat);;BIN Files (*.bin);;LOG Files (*.log);;All Files (*)"
        )
        
        if file_path:
            self.open_file(file_path)
    
    def open_file(self, file_path):
        """Open and parse a drone data file"""
        self.current_file = file_path
        self.file_label.setText(f"File: {os.path.basename(file_path)}")
        self.statusBar.showMessage(f"Loading {file_path}...")
        
        # Show progress bar
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)
        
        # Start loading thread
        self.load_thread = DataLoadThread(file_path)
        self.load_thread.progress_updated.connect(self.update_load_progress)
        self.load_thread.data_loaded.connect(self.on_data_loaded)
        self.load_thread.error_occurred.connect(self.on_load_error)
        self.load_thread.start()
        
        # Add to recent files
        self.add_to_recent_files(file_path)
    
    def update_load_progress(self, progress, message):
        """Update progress bar during file loading"""
        self.progress_bar.setValue(progress)
        self.statusBar.showMessage(message)
    
    def on_data_loaded(self, drone_data):
        """Handle loaded drone data"""
        self.drone_data = drone_data
        self.analyzer = DroneDataAnalyzer(drone_data)
        
        # Update UI
        self.progress_bar.setVisible(False)
        self.statusBar.showMessage(f"Loaded {self.current_file}")
        
        # Update drone model dropdown
        self.drone_model_combo.clear()
        self.drone_model_combo.addItems(drone_data.get_possible_models())
        self.drone_model_combo.setCurrentIndex(0)
        self.drone_model_combo.setEnabled(True)
        
        # Update views with data
        self.map_view.set_data(drone_data)
        self.telemetry_view.set_data(drone_data)
        self.timeline_view.set_data(drone_data)
        self.report_view.set_data(drone_data)
        
        # Automatically analyze the data
        self.analyze_data()
    
    def on_load_error(self, error_message):
        """Handle file loading error"""
        self.progress_bar.setVisible(False)
        self.statusBar.showMessage("Error loading file")
        
        QMessageBox.critical(self, "Error", error_message)
    
    def analyze_data(self):
        """Analyze the loaded drone data"""
        if not self.drone_data or not self.analyzer:
            QMessageBox.warning(self, "No Data", "Please load a drone data file first.")
            return
        
        try:
            self.statusBar.showMessage("Analyzing data...")
            
            # Perform analysis
            analysis_results = self.analyzer.analyze()
            
            # Update views with analysis results
            self.map_view.update_with_analysis(analysis_results)
            self.telemetry_view.update_with_analysis(analysis_results)
            self.timeline_view.update_with_analysis(analysis_results)
            self.report_view.update_with_analysis(analysis_results)
            
            self.statusBar.showMessage("Analysis complete")
        
        except Exception as e:
            self.statusBar.showMessage("Analysis failed")
            QMessageBox.critical(self, "Analysis Error", f"Error analyzing data: {str(e)}")
    
    def detect_anomalies(self):
        """Detect anomalies in the drone data"""
        if not self.drone_data or not self.analyzer:
            QMessageBox.warning(self, "No Data", "Please load a drone data file first.")
            return
        
        try:
            self.statusBar.showMessage("Detecting anomalies...")
            
            # Detect anomalies
            anomalies = self.analyzer.detect_anomalies()
            
            if anomalies:
                # Update views with anomalies
                self.map_view.highlight_anomalies(anomalies)
                self.telemetry_view.highlight_anomalies(anomalies)
                self.timeline_view.highlight_anomalies(anomalies)
                
                self.statusBar.showMessage(f"Detected {len(anomalies)} anomalies")
                
                # Show summary message
                QMessageBox.information(
                    self, 
                    "Anomalies Detected", 
                    f"Detected {len(anomalies)} anomalies in the drone data.\n\n"
                    "The anomalies have been highlighted in the respective views."
                )
            else:
                self.statusBar.showMessage("No anomalies detected")
                QMessageBox.information(self, "No Anomalies", "No anomalies were detected in the drone data.")
        
        except Exception as e:
            self.statusBar.showMessage("Anomaly detection failed")
            QMessageBox.critical(self, "Detection Error", f"Error detecting anomalies: {str(e)}")
    
    def generate_report(self):
        """Generate a report from the drone data"""
        if not self.drone_data or not self.analyzer:
            QMessageBox.warning(self, "No Data", "Please load a drone data file first.")
            return
        
        # Switch to report tab
        self.tabs.setCurrentWidget(self.report_view)
        
        # Let the report view handle report generation
        self.report_view.generate_report()
    
    def export_data(self, format_type):
        """Export drone data to various formats"""
        if not self.drone_data:
            QMessageBox.warning(self, "No Data", "Please load a drone data file first.")
            return
        
        try:
            # Determine default filename
            default_name = os.path.splitext(os.path.basename(self.current_file))[0]
            
            # Show save dialog
            file_dialog = QFileDialog()
            
            if format_type == "kml":
                file_path, _ = file_dialog.getSaveFileName(
                    self, "Export to KML", f"{default_name}.kml", "KML Files (*.kml)"
                )
                if file_path:
                    self.drone_data.export_to_kml(file_path)
            
            elif format_type == "csv":
                file_path, _ = file_dialog.getSaveFileName(
                    self, "Export to CSV", f"{default_name}_export.csv", "CSV Files (*.csv)"
                )
                if file_path:
                    self.drone_data.export_to_csv(file_path)
            
            elif format_type == "json":
                file_path, _ = file_dialog.getSaveFileName(
                    self, "Export to JSON", f"{default_name}.json", "JSON Files (*.json)"
                )
                if file_path:
                    self.drone_data.export_to_json(file_path)
            
            if file_path:
                self.statusBar.showMessage(f"Data exported to {file_path}")
        
        except Exception as e:
            self.statusBar.showMessage("Export failed")
            QMessageBox.critical(self, "Export Error", f"Error exporting data: {str(e)}")
    
    def show_about_dialog(self):
        """Show the about dialog"""
        QMessageBox.about(
            self,
            "About DroneForensics",
            "DroneForensics v1.0\n\n"
            "A forensic analysis tool for drone flight data.\n\n"
            "This tool allows investigators to analyze telemetry data, "
            "reconstruct flight paths, and examine payload information "
            "from various drone models."
        )
    
    def closeEvent(self, event):
        """Handle window close event"""
        self.save_settings()
        event.accept()
