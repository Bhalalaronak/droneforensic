#!/usr/bin/env python3
"""
DroneForensics - Map View
Provides visualization of drone flight paths on maps
"""

import os
import sys
import folium
import tempfile
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                           QComboBox, QCheckBox, QGroupBox, QPushButton,
                           QSlider, QSplitter, QTabWidget)
from PyQt5.QtCore import Qt, QUrl
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtGui import QColor

class MapView(QWidget):
    """Widget for displaying drone flight paths on maps"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.drone_data = None
        self.analysis_results = None
        self.map_html_path = None
        self.anomalies = []
        
        self.setup_ui()
    
    def setup_ui(self):
        """Set up the user interface"""
        layout = QVBoxLayout(self)
        
        # Create controls area
        controls_layout = QHBoxLayout()
        
        # Map type selection
        map_group = QGroupBox("Map Options")
        map_layout = QVBoxLayout(map_group)
        
        map_type_layout = QHBoxLayout()
        map_type_layout.addWidget(QLabel("Map Type:"))
        
        self.map_type_combo = QComboBox()
        self.map_type_combo.addItems(["OpenStreetMap", "Satellite", "Terrain", "Hybrid"])
        self.map_type_combo.currentIndexChanged.connect(self.update_map)
        map_type_layout.addWidget(self.map_type_combo)
        
        map_layout.addLayout(map_type_layout)
        
        # Display options
        self.show_waypoints = QCheckBox("Show Waypoints")
        self.show_waypoints.setChecked(True)
        self.show_waypoints.stateChanged.connect(self.update_map)
        map_layout.addWidget(self.show_waypoints)
        
        self.show_altitude = QCheckBox("Color by Altitude")
        self.show_altitude.setChecked(True)
        self.show_altitude.stateChanged.connect(self.update_map)
        map_layout.addWidget(self.show_altitude)
        
        self.show_speed = QCheckBox("Show Speed Indicators")
        self.show_speed.setChecked(False)
        self.show_speed.stateChanged.connect(self.update_map)
        map_layout.addWidget(self.show_speed)
        
        self.show_home_point = QCheckBox("Show Home Point")
        self.show_home_point.setChecked(True)
        self.show_home_point.stateChanged.connect(self.update_map)
        map_layout.addWidget(self.show_home_point)
        
        controls_layout.addWidget(map_group)
        
        # Time filter
        time_group = QGroupBox("Time Filter")
        time_layout = QVBoxLayout(time_group)
        
        self.time_slider = QSlider(Qt.Horizontal)
        self.time_slider.setRange(0, 100)
        self.time_slider.setValue(100)
        self.time_slider.setTickPosition(QSlider.TicksBelow)
        self.time_slider.setTickInterval(10)
        self.time_slider.valueChanged.connect(self.update_time_filter)
        time_layout.addWidget(self.time_slider)
        
        time_label_layout = QHBoxLayout()
        time_label_layout.addWidget(QLabel("Start"))
        self.time_value_label = QLabel("100%")
        time_label_layout.addWidget(self.time_value_label, 0, Qt.AlignRight)
        time_label_layout.addWidget(QLabel("End"))
        time_layout.addLayout(time_label_layout)
        
        controls_layout.addWidget(time_group)
        
        # Analysis options
        analysis_group = QGroupBox("Analysis")
        analysis_layout = QVBoxLayout(analysis_group)
        
        self.show_anomalies = QCheckBox("Highlight Anomalies")
        self.show_anomalies.setChecked(True)
        self.show_anomalies.stateChanged.connect(self.update_map)
        analysis_layout.addWidget(self.show_anomalies)
        
        self.show_no_fly_zones = QCheckBox("Show No-Fly Zones")
        self.show_no_fly_zones.setChecked(False)
        self.show_no_fly_zones.stateChanged.connect(self.update_map)
        analysis_layout.addWidget(self.show_no_fly_zones)
        
        controls_layout.addWidget(analysis_group)
        
        layout.addLayout(controls_layout)
        
        # Create map view
        self.map_tabs = QTabWidget()
        
        # 2D Map
        self.map_view = QWebEngineView()
        self.map_tabs.addTab(self.map_view, "2D Map")
        
        # 3D Map (will be initialized when data is loaded)
        self.map_3d_widget = QWidget()
        self.map_tabs.addTab(self.map_3d_widget, "3D View")
        
        layout.addWidget(self.map_tabs, 1)  # 1 = stretch factor
        
        # Initialize with empty map
        self.initialize_empty_map()
    
    def initialize_empty_map(self):
        """Initialize an empty map"""
        # Create a basic map centered on a default location
        m = folium.Map(location=[0, 0], zoom_start=2)
        
        # Add a message
        folium.Marker(
            location=[0, 0],
            popup="No data loaded. Please open a drone data file.",
            icon=folium.Icon(icon="info-sign")
        ).add_to(m)
        
        # Save to temporary file and display
        fd, self.map_html_path = tempfile.mkstemp(suffix=".html")
        os.close(fd)
        m.save(self.map_html_path)
        
        self.map_view.load(QUrl.fromLocalFile(self.map_html_path))
    
    def set_data(self, drone_data):
        """Set the drone data to display"""
        self.drone_data = drone_data
        
        if drone_data and drone_data.has_gps_data():
            self.update_map()
        else:
            # Show message if no GPS data
            self.initialize_empty_map_with_message("No GPS data available in the loaded file.")
    
    def initialize_empty_map_with_message(self, message):
        """Initialize an empty map with a custom message"""
        m = folium.Map(location=[0, 0], zoom_start=2)
        
        folium.Marker(
            location=[0, 0],
            popup=message,
            icon=folium.Icon(icon="info-sign")
        ).add_to(m)
        
        # Save to temporary file and display
        fd, self.map_html_path = tempfile.mkstemp(suffix=".html")
        os.close(fd)
        m.save(self.map_html_path)
        
        self.map_view.load(QUrl.fromLocalFile(self.map_html_path))
    
    def update_with_analysis(self, analysis_results):
        """Update the map with analysis results"""
        self.analysis_results = analysis_results
        self.update_map()
    
    def highlight_anomalies(self, anomalies):
        """Highlight anomalies on the map"""
        self.anomalies = anomalies
        
        # Ensure the checkbox is checked
        self.show_anomalies.setChecked(True)
        
        self.update_map()
    
    def update_time_filter(self):
        """Update the time filter based on slider value"""
        value = self.time_slider.value()
        self.time_value_label.setText(f"{value}%")
        self.update_map()
    
    def update_map(self):
        """Update the map based on current settings"""
        if not self.drone_data or not self.drone_data.has_gps_data():
            return
        
        # Get flight path data
        flight_path = self.drone_data.get_flight_path()
        
        # Apply time filter
        time_filter = self.time_slider.value() / 100.0
        if time_filter < 1.0:
            # Filter points based on time percentage
            total_points = len(flight_path)
            points_to_keep = int(total_points * time_filter)
            flight_path = flight_path[:points_to_keep]
        
        # Create map with selected base layer
        map_type = self.map_type_combo.currentText()
        
        if map_type == "OpenStreetMap":
            m = folium.Map(tiles="OpenStreetMap")
        elif map_type == "Satellite":
            m = folium.Map(tiles="Stamen Terrain")
        elif map_type == "Terrain":
            m = folium.Map(tiles="Stamen Terrain")
        else:  # Hybrid
            m = folium.Map(tiles="CartoDB positron")
        
        # Find center and zoom level
        if flight_path:
            # Calculate center as average of all points
            lats = [point['latitude'] for point in flight_path]
            lons = [point['longitude'] for point in flight_path]
            center_lat = sum(lats) / len(lats)
            center_lon = sum(lons) / len(lons)
            
            # Set center and zoom
            m.location = [center_lat, center_lon]
            m.zoom_start = 15
        
        # Add flight path
        if flight_path:
            # Create line coordinates
            line_coords = [(point['latitude'], point['longitude']) for point in flight_path]
            
            # Draw the flight path
            if self.show_altitude.isChecked():
                # Color by altitude
                # Create a choropleth-like effect with segments colored by altitude
                altitudes = [point.get('altitude', 0) for point in flight_path]
                min_alt = min(altitudes)
                max_alt = max(altitudes)
                
                # Create segments with color based on altitude
                for i in range(len(line_coords) - 1):
                    # Normalize altitude to 0-1 range
                    if max_alt > min_alt:
                        norm_alt = (altitudes[i] - min_alt) / (max_alt - min_alt)
                    else:
                        norm_alt = 0.5
                    
                    # Create color (blue to red gradient)
                    color = self.get_altitude_color(norm_alt)
                    
                    # Add line segment
                    folium.PolyLine(
                        [line_coords[i], line_coords[i+1]],
                        color=color,
                        weight=3,
                        opacity=0.8
                    ).add_to(m)
            else:
                # Single color path
                folium.PolyLine(
                    line_coords,
                    color="blue",
                    weight=3,
                    opacity=0.8
                ).add_to(m)
        
        # Add waypoints if enabled
        if self.show_waypoints.isChecked() and flight_path:
            # Add start point
            folium.Marker(
                location=line_coords[0],
                popup="Start Point",
                icon=folium.Icon(icon="play", color="green")
            ).add_to(m)
            
            # Add end point
            folium.Marker(
                location=line_coords[-1],
                popup="End Point",
                icon=folium.Icon(icon="stop", color="red")
            ).add_to(m)
            
            # Add intermediate waypoints (every 10% of the path)
            step = max(1, len(line_coords) // 10)
            for i in range(step, len(line_coords) - 1, step):
                point = flight_path[i]
                popup_text = f"Time: {point.get('timestamp', 'N/A')}<br>"
                popup_text += f"Altitude: {point.get('altitude', 'N/A')} m<br>"
                popup_text += f"Speed: {point.get('speed', 'N/A')} m/s"
                
                folium.CircleMarker(
                    location=line_coords[i],
                    radius=5,
                    popup=popup_text,
                    color="blue",
                    fill=True,
                    fill_color="blue"
                ).add_to(m)
        
        # Add home point if enabled
        if self.show_home_point.isChecked() and self.drone_data.has_home_point():
            home_point = self.drone_data.get_home_point()
            folium.Marker(
                location=[home_point['latitude'], home_point['longitude']],
                popup="Home Point",
                icon=folium.Icon(icon="home", color="purple")
            ).add_to(m)
        
        # Add speed indicators if enabled
        if self.show_speed.isChecked() and flight_path:
            # Add arrows for direction and speed (every 5% of the path)
            step = max(1, len(line_coords) // 20)
            for i in range(0, len(line_coords) - 1, step):
                if i + 1 < len(flight_path):
                    point = flight_path[i]
                    speed = point.get('speed', 0)
                    
                    if speed > 0:
                        # Scale arrow size based on speed
                        scale = min(1.0, speed / 10.0) * 3
                        
                        # Add an arrow icon
                        folium.RegularPolygonMarker(
                            location=line_coords[i],
                            number_of_sides=3,
                            radius=scale,
                            rotation=45,  # Adjust based on actual heading if available
                            popup=f"Speed: {speed} m/s",
                            color='#FF6B6B',
                            fill=True,
                            fill_color='#FF6B6B'
                        ).add_to(m)
        
        # Add no-fly zones if enabled and available
        if self.show_no_fly_zones.isChecked() and self.analysis_results and 'no_fly_zones' in self.analysis_results:
            for zone in self.analysis_results['no_fly_zones']:
                folium.Circle(
                    location=[zone['latitude'], zone['longitude']],
                    radius=zone['radius'],
                    popup=f"No-Fly Zone: {zone.get('name', 'Unknown')}",
                    color='red',
                    fill=True,
                    fill_opacity=0.2
                ).add_to(m)
        
        # Add anomalies if enabled
        if self.show_anomalies.isChecked() and self.anomalies:
            for anomaly in self.anomalies:
                if 'latitude' in anomaly and 'longitude' in anomaly:
                    # Create popup text
                    popup_text = f"Anomaly: {anomaly.get('type', 'Unknown')}<br>"
                    popup_text += f"Time: {anomaly.get('timestamp', 'N/A')}<br>"
                    popup_text += f"Confidence: {anomaly.get('confidence', 'N/A')}<br>"
                    popup_text += f"Description: {anomaly.get('description', 'N/A')}"
                    
                    # Add marker
                    folium.Marker(
                        location=[anomaly['latitude'], anomaly['longitude']],
                        popup=popup_text,
                        icon=folium.Icon(icon="warning-sign", color="orange")
                    ).add_to(m)
        
        # Save to temporary file and display
        if self.map_html_path:
            try:
                os.unlink(self.map_html_path)
            except:
                pass
        
        fd, self.map_html_path = tempfile.mkstemp(suffix=".html")
        os.close(fd)
        m.save(self.map_html_path)
        
        self.map_view.load(QUrl.fromLocalFile(self.map_html_path))
    
    def get_altitude_color(self, normalized_altitude):
        """Get color for altitude visualization (blue to red gradient)"""
        # Blue (low) to Red (high)
        if normalized_altitude < 0.25:
            # Blue to Cyan
            r = 0
            g = int(255 * (normalized_altitude * 4))
            b = 255
        elif normalized_altitude < 0.5:
            # Cyan to Green
            r = 0
            g = 255
            b = int(255 * (1 - (normalized_altitude - 0.25) * 4))
        elif normalized_altitude < 0.75:
            # Green to Yellow
            r = int(255 * ((normalized_altitude - 0.5) * 4))
            g = 255
            b = 0
        else:
            # Yellow to Red
            r = 255
            g = int(255 * (1 - (normalized_altitude - 0.75) * 4))
            b = 0
        
        return f"#{r:02x}{g:02x}{b:02x}"
