#!/usr/bin/env python3
"""
DroneForensics - Telemetry Data Model
Represents drone telemetry data
"""

import os
import json
import csv
import datetime
import simplekml

class DroneData:
    """Class representing drone telemetry data"""
    
    def __init__(self):
        self.drone_type = "Unknown"
        self.flight_path = []
        self.home_point = None
        self.payload_data = []
        self.metadata = {}
    
    def set_drone_type(self, drone_type):
        """Set the drone type"""
        self.drone_type = drone_type
    
    def get_drone_type(self):
        """Get the drone type"""
        return self.drone_type
    
    def set_flight_path(self, flight_path):
        """Set the flight path data"""
        self.flight_path = flight_path
    
    def get_flight_path(self):
        """Get the flight path data"""
        return self.flight_path
    
    def set_home_point(self, home_point):
        """Set the home point"""
        self.home_point = home_point
    
    def get_home_point(self):
        """Get the home point"""
        return self.home_point
    
    def has_home_point(self):
        """Check if home point is available"""
        return self.home_point is not None
    
    def set_payload_data(self, payload_data):
        """Set the payload data"""
        self.payload_data = payload_data
    
    def get_payload_data(self):
        """Get the payload data"""
        return self.payload_data
    
    def set_metadata(self, metadata):
        """Set metadata"""
        self.metadata = metadata
    
    def get_metadata(self):
        """Get metadata"""
        return self.metadata
    
    def has_gps_data(self):
        """Check if the data contains GPS coordinates"""
        return len(self.flight_path) > 0 and 'latitude' in self.flight_path[0] and 'longitude' in self.flight_path[0]
    
    def get_flight_duration(self):
        """Get the flight duration in seconds"""
        if len(self.flight_path) < 2:
            return 0
        
        # Try to get timestamps
        if 'timestamp' in self.flight_path[0] and 'timestamp' in self.flight_path[-1]:
            try:
                # Try parsing as datetime string
                start_time = self.parse_timestamp(self.flight_path[0]['timestamp'])
                end_time = self.parse_timestamp(self.flight_path[-1]['timestamp'])
                
                if start_time and end_time:
                    return (end_time - start_time).total_seconds()
            except:
                # If parsing fails, return 0
                return 0
        
        return 0
    
    def parse_timestamp(self, timestamp):
        """Parse a timestamp string into a datetime object"""
        if isinstance(timestamp, (int, float)):
            # Assume Unix timestamp
            return datetime.datetime.fromtimestamp(timestamp)
        
        # Try common datetime formats
        formats = [
            '%Y-%m-%d %H:%M:%S',
            '%Y-%m-%d %H:%M:%S.%f',
            '%Y/%m/%d %H:%M:%S',
            '%d/%m/%Y %H:%M:%S',
            '%m/%d/%Y %H:%M:%S',
            '%Y-%m-%dT%H:%M:%S',
            '%Y-%m-%dT%H:%M:%S.%f'
        ]
        
        for fmt in formats:
            try:
                return datetime.datetime.strptime(timestamp, fmt)
            except ValueError:
                continue
        
        return None
    
    def get_max_altitude(self):
        """Get the maximum altitude"""
        if not self.flight_path:
            return 0
        
        altitudes = [point.get('altitude', 0) for point in self.flight_path if 'altitude' in point]
        return max(altitudes) if altitudes else 0
    
    def get_max_speed(self):
        """Get the maximum speed"""
        if not self.flight_path:
            return 0
        
        speeds = [point.get('speed', 0) for point in self.flight_path if 'speed' in point]
        return max(speeds) if speeds else 0
    
    def get_total_distance(self):
        """Calculate the total distance traveled in meters"""
        if len(self.flight_path) < 2:
            return 0
        
        total_distance = 0
        for i in range(1, len(self.flight_path)):
            prev_point = self.flight_path[i-1]
            curr_point = self.flight_path[i]
            
            if 'latitude' in prev_point and 'longitude' in prev_point and 'latitude' in curr_point and 'longitude' in curr_point:
                distance = self.calculate_distance(
                    prev_point['latitude'], prev_point['longitude'],
                    curr_point['latitude'], curr_point['longitude']
                )
                total_distance += distance
        
        return total_distance
    
    def calculate_distance(self, lat1, lon1, lat2, lon2):
        """Calculate distance between two points using Haversine formula"""
        from math import radians, sin, cos, sqrt, atan2
        
        # Radius of the Earth in meters
        R = 6371000
        
        # Convert latitude and longitude from degrees to radians
        lat1_rad = radians(lat1)
        lon1_rad = radians(lon1)
        lat2_rad = radians(lat2)
        lon2_rad = radians(lon2)
        
        # Differences
        dlat = lat2_rad - lat1_rad
        dlon = lon2_rad - lon1_rad
        
        # Haversine formula
        a = sin(dlat/2)**2 + cos(lat1_rad) * cos(lat2_rad) * sin(dlon/2)**2
        c = 2 * atan2(sqrt(a), sqrt(1-a))
        distance = R * c
        
        return distance
    
    def get_possible_models(self):
        """Get possible drone models based on data"""
        if self.drone_type == "DJI":
            return ["DJI Phantom", "DJI Mavic", "DJI Inspire", "DJI Matrice", "Unknown DJI"]
        elif self.drone_type == "Parrot":
            return ["Parrot Anafi", "Parrot Bebop", "Parrot Disco", "Unknown Parrot"]
        elif self.drone_type == "Yuneec":
            return ["Yuneec Typhoon", "Yuneec H520", "Unknown Yuneec"]
        elif self.drone_type == "Autel":
            return ["Autel EVO", "Autel EVO II", "Unknown Autel"]
        else:
            return ["Unknown Drone"]
    
    def export_to_kml(self, file_path):
        """Export flight path to KML file"""
        if not self.has_gps_data():
            raise ValueError("No GPS data available to export")
        
        kml = simplekml.Kml()
        
        # Create a folder for the flight path
        folder = kml.newfolder(name="Drone Flight Path")
        
        # Add flight path as a LineString
        linestring = folder.newlinestring(name="Flight Path")
        coordinates = [(point['longitude'], point['latitude'], point.get('altitude', 0)) 
                      for point in self.flight_path]
        linestring.coords = coordinates
        linestring.extrude = 1
        linestring.altitudemode = simplekml.AltitudeMode.absolute
        linestring.style.linestyle.width = 4
        linestring.style.linestyle.color = simplekml.Color.blue
        
        # Add home point if available
        if self.has_home_point():
            home = folder.newpoint(name="Home Point")
            home.coords = [(self.home_point['longitude'], self.home_point['latitude'])]
            home.style.iconstyle.icon.href = 'http://maps.google.com/mapfiles/kml/paddle/H.png'
        
        # Add start point
        if self.flight_path:
            start = folder.newpoint(name="Start Point")
            start.coords = [(self.flight_path[0]['longitude'], self.flight_path[0]['latitude'])]
            start.style.iconstyle.icon.href = 'http://maps.google.com/mapfiles/kml/paddle/grn-circle.png'
        
        # Add end point
        if len(self.flight_path) > 1:
            end = folder.newpoint(name="End Point")
            end.coords = [(self.flight_path[-1]['longitude'], self.flight_path[-1]['latitude'])]
            end.style.iconstyle.icon.href = 'http://maps.google.com/mapfiles/kml/paddle/red-circle.png'
        
        # Save the KML file
        kml.save(file_path)
    
    def export_to_csv(self, file_path):
        """Export flight path to CSV file"""
        if not self.flight_path:
            raise ValueError("No flight path data available to export")
        
        # Get all unique keys from all points
        keys = set()
        for point in self.flight_path:
            keys.update(point.keys())
        
        # Sort keys for consistent output
        sorted_keys = sorted(keys)
        
        # Write to CSV
        with open(file_path, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=sorted_keys)
            writer.writeheader()
            writer.writerows(self.flight_path)
    
    def export_to_json(self, file_path):
        """Export all data to JSON file"""
        data = {
            'drone_type': self.drone_type,
            'flight_path': self.flight_path,
            'home_point': self.home_point,
            'payload_data': self.payload_data,
            'metadata': self.metadata,
            'statistics': {
                'max_altitude': self.get_max_altitude(),
                'max_speed': self.get_max_speed(),
                'total_distance': self.get_total_distance(),
                'flight_duration': self.get_flight_duration()
            }
        }
        
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)
